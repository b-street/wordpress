<?php

/**
 * @var $section array
 * @var $id string
 * @var $content string
 */

?>
<div class="es-tabbed-item <?php echo $id; ?>" id="<?php echo $id; ?>">
    <h3><?php echo $section['label']; ?></h3>
    <?php echo $content; ?>
</div>