<p style="font-size: 14px; line-height: 30px; color:#6c6c6c; font-family: 'Open Sans', Arial, sans-serif; margin: 0; padding: 0;">
	<?php echo $message; ?>
</p>
