<?php es_load_template( 'archive-properties.php' );
