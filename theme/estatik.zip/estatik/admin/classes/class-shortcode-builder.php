<?php

class Es_Shortcode_Builder {

	public static function get_shortcodes() {

	}
}
