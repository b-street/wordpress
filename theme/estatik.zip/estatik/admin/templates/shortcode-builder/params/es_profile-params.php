<div class="est-form-row">
	<div class="est-field">
		<label for="es-layout-field"><?php _e( 'Layout', 'es-plugin' ); ?>:</label>
		<div class="est-field__content">
			<select id="es-layout-field" name="attr[layout]">
				<option value="vertical"><?php _e( 'Vertical', 'es-plugin' ); ?></option>
				<option value="horizontal"><?php _e( 'Horizontal', 'es-plugin' ); ?></option>
			</select>
		</div>
	</div>
</div>