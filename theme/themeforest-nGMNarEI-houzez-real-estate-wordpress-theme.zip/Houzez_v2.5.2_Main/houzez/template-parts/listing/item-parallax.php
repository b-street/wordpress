<div class="item-listing-parallax" style="height: 600px;">
	<div class="item-parallax-inner parallax" data-parallax-bg-image="img/miami-beach-1.jpg">
		<div class="item-parallax-wrap" data-aos="fade">
			<?php include 'inc/listing/templates/item-featured-label.php';?>
			<?php include 'inc/listing/templates/item-labels.php';?>
			<?php include 'inc/listing/templates/item-title.php';?>
			<?php include 'inc/listing/templates/item-address.php';?>
			<?php include 'inc/listing/templates/item-price.php';?>
			<?php include 'inc/listing/templates/item-features-v1.php';?>
		</div><!-- item-parallax-wrap -->
	</div><!-- parallax -->
</div><!-- item-listing-parallax -->