<div class="breadcrumb-wrap">
	<nav>
		<ol class="breadcrumb">
			<li class="breadcrumb-item"><strong class="primary-text">Step 1</strong> 0f 12</li>
		</ol><!-- breadcrumb -->
	</nav>
</div>