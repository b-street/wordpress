=== Import Properties into Houzez Theme ===
Contributors: soflyy, wpallimport
Tags: real estate, import real estate, import real estate listings, import properties, import property listings, houzez, houzez theme, import houzez, import houzez properties, import houzez listings, import houzez, import houzez properties, import houzez listings
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Requires at least: 4.2.0
Tested up to: 4.5.3
Stable tag: 1.0.0

Easily import property listings from any XML or CSV file to the Houzez theme with the Houzez Add-On for WP All Import.

== Description ==

The Houzez Add-On for [WP All Import](http://wordpress.org/plugins/wp-all-import "WordPress XML & CSV Import") makes it easy to bulk import your property listings to the Houzez theme in less than 10 minutes.

The left side shows all of the fields that you can import to and the right side displays a property listing from your XML/CSV file. Then you can simply drag & drop the data from your XML or CSV into the Houzez fields to import it.

The importer is so intuitive it is almost like manually adding a property listing in Houzez.